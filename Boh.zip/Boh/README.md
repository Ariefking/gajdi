# BOT PY3 #
# RAMBATE RATA HAYO #
------
Cara Install Bot :
------
C9 SERVER/ VPS :
- `sudo apt-get update -y`
- `sudo apt-get install git -y`
- `sudo apt-get install python3-pip -y`
- `sudo pip3 install rsa`
- `sudo pip3 install thrift==0.11.0`
- `sudo pip3 install requests`
- `sudo pip3 install pytz`
- `sudo pip3 install bs4`
- `sudo pip3 install gtts`
- `sudo pip3 install googletrans`
- `sudo pip3 install humanfriendly`
- `sudo pip3 install goslate`
- `sudo pip3 install pafy`
- `sudo pip3 install wikipedia`
- `sudo pip3 install tweepy`
- `sudo pip3 install youtube_dl`
- `git clone https://github.com/6ul4n/BULPY3`
- `cd BULPY3`
- `python3 bul.py`

INSTALL Di TERMUX :
- `pkg update`
- `pkg install git`
- `pkg install python3-pip`
- `pip3 install rsa`
- `pip3 install thrift==0.11.0`
- `pip3 install requests`
- `pip3 install bs4`
- `pip3 install gtts`
- `pip3 install beautifulsoup`
- `pip3 install googletrans`
- `pip3 install pafy`
- `pip3 install humanfriendly`
- `pip3 install goslate`
- `pip3 install wikipedia`
- `pip3 install youtube_dl`
- `pip3 install tweepy`
- `git clone https://github.com/6ul4n/BULPY3`
- `cd BULPY3`
- `python3 bul.py`

Cara Menjalankan Bot Kembali :
------
Di C9 :
- `cd BULPY3`
- `python3 bul.py`

Di Termux :
- `cd BULPY3`
- `python3 bul.py`


